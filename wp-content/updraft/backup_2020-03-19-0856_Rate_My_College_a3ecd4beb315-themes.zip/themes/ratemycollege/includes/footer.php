<?php
remove_action("genesis_footer",	"genesis_footer_markup_open",5);
remove_action("genesis_footer",	"genesis_do_footer");
remove_action("genesis_footer",	"genesis_footer_markup_close",15);
remove_action("genesis_footer",	"genesis_do_subnav",7);
add_action("genesis_footer",	"tl_custom_footer");
function tl_custom_footer(){

	?>
  <footer class="site-footer" itemscope="" itemtype="https://schema.org/WPFooter">
  <div class="wrap">
   <div class="site-footer-left">
    <a href="<?php echo home_url(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo-footer.png" /></a>
   </div>   
<div class="site-footer-right">
<div class="site-footer-right-above">
 <a href="https://twitter.com/unfnshedbusines" target="_blank" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
 <a href="https://www.instagram.com/_unfinshedbusiness/" target="_blank" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
 </div>
 <div class="site-footer-right-below">
    <?php genesis_do_subnav(); ?>
  </div>
</div>
    </div></footer>
    <?php

}